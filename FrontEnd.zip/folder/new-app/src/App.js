import logo from './logo.svg';
import React from "react";
import './App.css';
import Body from "./components/Body"
import Game from "./components/Game"
import Dashboard from "./components/Dashboard"
import {BrowserRouter as Router, Route,Switch,Link} from "react-router-dom"
class App extends React.Component  {
  state={
    currentName:""
  }
  updateInput = async(e) =>{
    console.log(e.target.value)
    this.setState({currentName:e.target.value.toString()})
}
render(){
  return (
    <Router>
    <Switch>
              <Route exact path='/login' render={
    props => <Body{...props} updateInput={this.updateInput} nickName={this.state.currentName}/>
} />
 <Route exact path='/game' render={
    props => <Game{...props} updateInput={this.updateInput} nickName={this.state.currentName}/>
} />
 <Route exact path='/dashboard' render={
    props => <Dashboard{...props} updateInput={this.updateInput} nickName={this.state.currentName}/>
} />
          </Switch>
          </Router>
  );
}
}

export default App;
