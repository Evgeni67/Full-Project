import React from "react";
import {
  Form,
  Navbar,
  Nav,
  FormControl,
  Image,
  Dropdown,
  Container,
  ListGroup,
  Button,
  Row,Col
} from "react-bootstrap";
import {BrowserRouter as Router, Route,Switch,Link} from "react-router-dom"

import'../Evgeni.css'
import 'bootstrap/dist/css/bootstrap.min.css';
class Body extends React.Component {
    state={
        currentName:""
        //currentQuestion:"",
       // firstAnswer:"",
       // secondAnswer:"",
        //thirdAnswer:"",
       // fourthAnswer:"",
       // yourCurrentAnswer:"",
       // currentScore:0
    }
    
    render(){
        return(
            <>
            <Row>
              <Col sm = {4}> </Col>
              <Col sm = {4}> 
            <Container className = "mainContainer" 
   >
            <Row className = "row"><Col sm = {4} xs={1}></Col><form className="form">
  <p className = "font-link">
   Your Name
  </p>

    <input type="text" className="name" onChange={(e)=>this.props.updateInput(e)}/>
    <Link to="/game">
  <input type="submit" value="Enter" className = "button" />
  </Link>
</form><Col sm = {4} xs={1}></Col></Row>
            
            </Container>
            </Col>
            <Col sm = {4}> </Col>
            </Row>
            </>
        )
    }
}
export default Body;
