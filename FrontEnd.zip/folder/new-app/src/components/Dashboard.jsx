import React from "react";
import {
  Form,
  Navbar,
  Nav,
  FormControl,
  Image,
  Dropdown,
  Container,
  ListGroup,
  Button,
  Row,Col
} from "react-bootstrap";
import {BrowserRouter as Router, Route,Switch,Link} from "react-router-dom"

import'../dashboard.css'
import 'bootstrap/dist/css/bootstrap.min.css';
class Dashboard extends React.Component {
    state={
        exams:[]
    }
    componentDidMount = async() => {
        const requestOptions = {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' },
        };
       await fetch(`http://localhost:3003/exams/getExams`,requestOptions)
            .then(response => response.json()).then(body => this.setState({exams:body.sort(function(a, b){
                return b.score-a.score // wtf
            })}))
    }
render(){
    return(<>
    <Container style={{ 
      backgroundImage: `url("https://wallpaperaccess.com/full/1188236.jpg")` 
    }}>
    <Row className ="line"><Col className = "col"sm={4}>Nickname</Col> 
    <Col className = "col"sm={4}>Date</Col> 
    <Col className = "col"sm={4}>Score</Col> 
    </Row>
    {this.state.exams.length>0 && this.state.exams.map(exam => (

        
    <Row className ="line"><Col className = "col"sm={4}>{exam.nickName}</Col> 
    <Col className = "col"sm={4}>{exam.examDate}</Col> 
    <Col className = "col"sm={4}>{exam.score} / 5</Col> 
    </Row>
    
    
    
    
    
    )
    )}
    <Row className ="playLine" >
    <a className = "play" href="/login">Play</a>
    </Row>
     </Container>
    </>
    )
}
}
export default Dashboard;
