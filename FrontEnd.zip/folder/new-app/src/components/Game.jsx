import React from "react";
import {
  Form,
  Navbar,
  Nav,
  FormControl,
  Image,
  Dropdown,
  Container,
  ListGroup,
  Button,
  Row,Col
} from "react-bootstrap";
import {BrowserRouter as Router, Route,Switch,Link} from "react-router-dom"

import'../Evgeni2.css'
import 'bootstrap/dist/css/bootstrap.min.css';
class Body extends React.Component {
    state={
        gotData:[],
        currentName:"",
       currentQuestions:[],
       currentQuestion:[],
      currentAnswers:[],
       yourCurrentAnswer:"",
        currentScore:0,
        firstMount: true,
        counter:0,
        score:0
    }
    fetchExam=async()=> {
if(this.state.firstMount){
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickName: this.props.nickName})
    };
   await fetch('http://localhost:3003/exams', requestOptions)
        .then(response => response.json())
        .then(data => this.setState({gotData:data,currentQuestions:data.randomQs,currentQuestion:data.randomQs[0].text, firstMount:false,currentAnswers:data.randomQs[0].answers}));
        
  
    }
}
componentDidMount = async() => {
    if(this.state.firstMount){
        await this.fetchExam()
        this.setState({firstMount:false})
    }
}

updateScore = async() => {
    const answer = {"empty":true}
    const requestOptions = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(answer)
    };
   await fetch(`http://localhost:3003/exams/updateScore/${this.state.gotData.id}`, requestOptions)
        .then(response => response.json()).then(body => console.log(body))
}
getNewScore = async() =>{
    this.updateScore()
    const requestOptions = {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
    };
   await fetch(`http://localhost:3003/exams/getExam/${this.state.gotData.id}`, requestOptions)
        .then(response => response.json()).then(body => this.setState({currentScore:body[0].score}))
}

 sendAnswer = async(index) =>{
     
     const answer = {"question": this.state.counter, "answer":index}
     const requestOptions = {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(answer)
    };
   await fetch(`http://localhost:3003/exams/updateExam/${this.state.gotData.id}`, requestOptions)
        .then(response => response.json()).then(body => console.log(body))
     this.next()
     if(this.state.counter === 6 ){
        alert(`the game has finished please stop clicking`)
    }
 }
       next = async() =>{
           try{
            await this.setState({counter:this.state.counter+=1})
          this.getNewScore()
            this.setState({currentQuestion:this.state.gotData.randomQs[this.state.counter].text, currentAnswers:this.state.gotData.randomQs[this.state.counter].answers})
    }catch(err){
    console.log(err)
    }
       }
    render(){
        return(
            <>
            <Container>
            <p className = "question">{this.state.currentQuestion}</p>
        <Row className = "answerRow">
            <Col sm={2}><p className= "score">Your score : {this.state.currentScore}</p></Col>
            <Col sm ={4} className="answerCol" onClick = {() => this.sendAnswer(1)}>{this.state.currentAnswers.length !==0 && this.state.currentAnswers[0].text}</Col> 
            <Col sm ={4} className="answerCol" onClick = {() => this.sendAnswer(2)}>{this.state.currentAnswers.length !==0 && this.state.currentAnswers[1].text}</Col>
        </Row>
      
        <Row className = "answerRow">
        <Col sm={2}></Col>
            <Col sm ={4} className="answerCol"onClick = {() => this.sendAnswer(3)}>{this.state.currentAnswers.length !==0 && this.state.currentAnswers[2].text}</Col> 
            <Col sm ={4} className="answerCol"onClick = {() => this.sendAnswer(4)}>{this.state.currentAnswers.length !==0 && this.state.currentAnswers[3].text}</Col>
        </Row>
        <Row className = "answerRow">
        <Col sm={2}></Col>
            <Col sm ={4} ><Button className = "nextBtn" href="/login">Play Again</Button></Col> 
            <Col sm ={4} > <Button className = "nextBtn" href="/dashboard">See Dasboard</Button></Col>
        </Row>
        </Container>
        </>)
    }
}
        export default Body;
        