const express = require("express");
const cors = require("cors");
const { join } = require("path");
const questionsRoutes = require("./questions");
const examsRoutes = require("./questions");
const server = express();
const port = process.env.PORT || 3003;
server.use(cors());
server.use(express.json()); 
const loggerMiddleware = (req, res, next) => {
  console.log(`Logged ${req.url} ${req.method} -- ${new Date()}`);
  next();
};
server.use("/questions", questionsRoutes);
server.use("/exams", examsRoutes);
server.use(loggerMiddleware);
server.listen(port, () => {
  console.log("Server is running on port: ", port);
});
